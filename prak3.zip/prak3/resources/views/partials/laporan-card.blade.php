<div class="card">
    <h3>Pelapor: {{ $report['reporter'] }}</h3>
    <p><strong>Lokasi:</strong> {{ $report['location'] }}</p>
    <p><strong>Tinggi Genangan:</strong> {{ $report['height'] }} cm</p>

    <p><strong>Status:</strong> 
        @if($report['height'] < 30)
            <span class="badge badge-waspada">Waspada</span>
        @elseif($report['height'] >= 30 && $report['height'] <= 70)
            <span class="badge badge-siaga">Siaga</span>
        @else
            <span class="badge badge-awas">Awas</span>
        @endif
    </p>
</div>