@extends('layouts.app')

@section('title', 'Daftar Laporan Banjir')

@section('content')
    <h2>Daftar Laporan Banjir Terkini</h2>
    <p>Berikut adalah daftar laporan kejadian banjir yang masuk dari masyarakat wilayah Kabupaten Bandung.</p>
    
    <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

    @forelse($reports as $report)
        {{-- Memanggil Partial Kartu Laporan --}}
        @include('partials.laporan-card', ['report' => $report])
    @empty
        <p>Belum ada laporan banjir yang tercatat saat ini.</p>
    @endforelse
@endsection