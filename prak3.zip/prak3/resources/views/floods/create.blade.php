@extends('layouts.app')

@section('title', 'Form Pelaporan Banjir')

@section('content')
    <h2>Form Pelaporan Banjir</h2>
    <p>Silakan isi formulir di bawah ini untuk melaporkan kejadian banjir di sekitar Anda.</p>

    <form action="{{ route('floods.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="reporter">Nama Lengkap Pelapor:</label>
            <input type="text" id="reporter" name="reporter" required placeholder="Masukkan nama Anda">
        </div>

        <div class="form-group">
            <label for="location">Lokasi Kejadian:</label>
            <input type="text" id="location" name="location" required placeholder="Contoh: Baleendah, Kab. Bandung">
        </div>

        <div class="form-group">
            <label for="height">Tinggi Genangan Air (cm):</label>
            <input type="number" id="height" name="height" required placeholder="Contoh: 50">
        </div>

        <button type="submit">Kirim Laporan</button>
    </form>
@endsection