@extends('layouts.app')

@section('title', 'Konfirmasi Laporan')

@section('content')
    <h2>Konfirmasi Laporan Banjir</h2>

    {{-- Memanggil Komponen Alert Bawaan Praktikum --}}
    <x-alert type="success" message="Laporan berhasil dikirim dan dicatat oleh sistem BPBD." />

    <div class="card" style="margin-top: 20px;">
        <h3>Detail Data yang Dikirim:</h3>
        <p><strong>Nama Pelapor:</strong> {{ $data['reporter'] }}</p>
        <p><strong>Lokasi:</strong> {{ $data['location'] }}</p>
        <p><strong>Tinggi Genangan:</strong> {{ $data['height'] }} cm</p>

        <p><strong>Status Genangan:</strong> 
            @if($data['height'] < 30)
                <span class="badge badge-waspada">Waspada</span>
            @elseif($data['height'] >= 30 && $data['height'] <= 70)
                <span class="badge badge-siaga">Siaga</span>
            @else
                <span class="badge badge-awas">Awas</span>
            @endif
        </p>
    </div>

    <br>
    <a href="{{ route('floods.index') }}"><button type="button">Lihat Semua Laporan</button></a>
@endsection