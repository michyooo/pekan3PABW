<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>@yield('title') | LaporBanjir BPBD</title>
</head>
<body>

    <header>
        <h1>LaporBanjir - BPBD Bandung</h1>
        <nav>
            <a href="{{ route('floods.index') }}">Daftar Laporan</a> | 
            <a href="{{ route('floods.create') }}">Buat Laporan</a>
        </nav>
    </header>

    <hr>

    <main>
        @yield('content')
    </main>

    <hr>

    <footer>
        <p>&copy; 2025 Badan Penanggulangan Bencana Daerah (BPBD) Kabupaten Bandung</p>
    </footer>

</body>
</html>