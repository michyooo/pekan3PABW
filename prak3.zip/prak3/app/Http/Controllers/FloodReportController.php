<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FloodReportController extends Controller
{
    // Menampilkan halaman daftar laporan banjir
    public function index()
    {
        $reports = [
            [
                'reporter' => 'Budi Santoso',
                'location' => 'Dayeuhkolot, Kab. Bandung',
                'height' => 85, // Kategori Awas (> 70 cm)
            ],
            [
                'reporter' => 'Siti Aminah',
                'location' => 'Baleendah, Kab. Bandung',
                'height' => 45, // Kategori Siaga (30 - 70 cm)
            ],
            [
                'reporter' => 'Ahmad Fauzi',
                'location' => 'Rancaekek, Kab. Bandung',
                'height' => 20, // Kategori Waspada (< 30 cm)
            ],
        ];

        return view('floods.index', compact('reports'));
    }

    // Menampilkan halaman form pelaporan
    public function create()
    {
        return view('floods.create');
    }

    // Menampilkan halaman konfirmasi setelah form dikirim (POST)
    public function store(Request $request)
    {
        // Mengambil data yang dikirim dari form
        $data = [
            'reporter' => $request->input('reporter'),
            'location' => $request->input('location'),
            'height' => $request->input('height'),
        ];

        return view('floods.confirmation', compact('data'));
    }
}