<?php $__env->startSection('title', 'Daftar Laporan Banjir'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Daftar Laporan Banjir Terkini</h2>
    <p>Berikut adalah daftar laporan kejadian banjir yang masuk dari masyarakat wilayah Kabupaten Bandung.</p>
    
    <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <?php echo $__env->make('partials.laporan-card', ['report' => $report], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Belum ada laporan banjir yang tercatat saat ini.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mchaelgieo/prak3/resources/views/floods/index.blade.php ENDPATH**/ ?>