<?php $__env->startSection('title', 'Form Pelaporan Banjir'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Form Pelaporan Banjir</h2>
    <p>Silakan isi formulir di bawah ini untuk melaporkan kejadian banjir di sekitar Anda.</p>

    <form action="<?php echo e(route('floods.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="reporter">Nama Lengkap Pelapor:</label>
            <input type="text" id="reporter" name="reporter" required placeholder="Masukkan nama Anda">
        </div>

        <div class="form-group">
            <label for="location">Lokasi Kejadian:</label>
            <input type="text" id="location" name="location" required placeholder="Contoh: Baleendah, Kab. Bandung">
        </div>

        <div class="form-group">
            <label for="height">Tinggi Genangan Air (cm):</label>
            <input type="number" id="height" name="height" required placeholder="Contoh: 50">
        </div>

        <button type="submit">Kirim Laporan</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mchaelgieo/prak3/resources/views/floods/create.blade.php ENDPATH**/ ?>