<div style="padding:10px; border:1px solid <?php echo e($type === 'error' ? 'red' : 'green'); ?>; margin:10px 0;">
    <strong> <?php echo e(ucfirst($type)); ?>:</strong> <?php echo e($message); ?>

</div><?php /**PATH /Users/mchaelgieo/prak3/resources/views/components/alert.blade.php ENDPATH**/ ?>