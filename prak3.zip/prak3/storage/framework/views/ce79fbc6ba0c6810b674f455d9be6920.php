<div class="card">
    <h3>Pelapor: <?php echo e($report['reporter']); ?></h3>
    <p><strong>Lokasi:</strong> <?php echo e($report['location']); ?></p>
    <p><strong>Tinggi Genangan:</strong> <?php echo e($report['height']); ?> cm</p>

    <p><strong>Status:</strong> 
        <?php if($report['height'] < 30): ?>
            <span class="badge badge-waspada">Waspada</span>
        <?php elseif($report['height'] >= 30 && $report['height'] <= 70): ?>
            <span class="badge badge-siaga">Siaga</span>
        <?php else: ?>
            <span class="badge badge-awas">Awas</span>
        <?php endif; ?>
    </p>
</div><?php /**PATH /Users/mchaelgieo/prak3/resources/views/partials/laporan-card.blade.php ENDPATH**/ ?>