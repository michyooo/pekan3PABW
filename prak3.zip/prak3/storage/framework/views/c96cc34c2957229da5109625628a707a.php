<div class="card">
    <h3><?php echo e($student['name']); ?></h3>
    <p><strong>Jurusan:</strong> <?php echo e($student['major']); ?></p>
    <p><strong>Umur:</strong> <?php echo e($student['age']); ?> tahun</p>

    <?php if($student['age'] >= 22): ?>
        <p>Status: <span style="color:green;">Senior</span></p>
    <?php else: ?>
        <p>Status: <span style="color:blue;">Junior</span></p>
    <?php endif; ?>

    <h4>Mata Kuliah:</h4>
    <?php $__empty_1 = true; $__currentLoopData = $student['courses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <span class="course"><?php echo e($course); ?></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Tidak ada mata kuliah terdaftar.</p>
    <?php endif; ?>
</div><?php /**PATH /Users/mchaelgieo/prak3/resources/views/partials/student-card.blade.php ENDPATH**/ ?>