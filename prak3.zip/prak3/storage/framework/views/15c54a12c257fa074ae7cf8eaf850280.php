<?php $__env->startSection('title', 'Konfirmasi Laporan'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Konfirmasi Laporan Banjir</h2>

    
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','message' => 'Laporan berhasil dikirim dan dicatat oleh sistem BPBD.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','message' => 'Laporan berhasil dikirim dan dicatat oleh sistem BPBD.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

    <div class="card" style="margin-top: 20px;">
        <h3>Detail Data yang Dikirim:</h3>
        <p><strong>Nama Pelapor:</strong> <?php echo e($data['reporter']); ?></p>
        <p><strong>Lokasi:</strong> <?php echo e($data['location']); ?></p>
        <p><strong>Tinggi Genangan:</strong> <?php echo e($data['height']); ?> cm</p>

        <p><strong>Status Genangan:</strong> 
            <?php if($data['height'] < 30): ?>
                <span class="badge badge-waspada">Waspada</span>
            <?php elseif($data['height'] >= 30 && $data['height'] <= 70): ?>
                <span class="badge badge-siaga">Siaga</span>
            <?php else: ?>
                <span class="badge badge-awas">Awas</span>
            <?php endif; ?>
        </p>
    </div>

    <br>
    <a href="<?php echo e(route('floods.index')); ?>"><button type="button">Lihat Semua Laporan</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mchaelgieo/prak3/resources/views/floods/confirmation.blade.php ENDPATH**/ ?>