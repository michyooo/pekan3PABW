<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> | LaporBanjir BPBD</title>
</head>
<body>

    <header>
        <h1>LaporBanjir - BPBD Bandung</h1>
        <nav>
            <a href="<?php echo e(route('floods.index')); ?>">Daftar Laporan</a> | 
            <a href="<?php echo e(route('floods.create')); ?>">Buat Laporan</a>
        </nav>
    </header>

    <hr>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <hr>

    <footer>
        <p>&copy; 2025 Badan Penanggulangan Bencana Daerah (BPBD) Kabupaten Bandung</p>
    </footer>

</body>
</html><?php /**PATH /Users/mchaelgieo/prak3/resources/views/layouts/app.blade.php ENDPATH**/ ?>