<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\FloodReportController;

// Route untuk Daftar Laporan Banjir
Route::get('/lapor-banjir', [FloodReportController::class, 'index'])->name('floods.index');

// Route untuk Form Pelaporan (GET untuk menampilkan form, POST untuk mengirim data)
Route::get('/lapor-banjir/create', [FloodReportController::class, 'create'])->name('floods.create');
Route::post('/lapor-banjir/store', [FloodReportController::class, 'store'])->name('floods.store');

Route::get('/students', [StudentController::class, 'index'])->name('students.index');
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
